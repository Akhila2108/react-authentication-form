import React, { useState } from "react";
import axios from "axios";
import './signup.css';
import { Link,useNavigate } from "react-router-dom";


function Signup() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [email, setEmail] = useState('');

const navigate=useNavigate();

  const handleSignup = async() => {
    const userdetails= {
      username,
      password,
      email
    };
    try {
      const response=await axios.post("http://localhost:8080/api/Signupdata", userdetails); 
      console.log(response.data);
      
      // Send a POST request to the backend endpoint
      if(response.status === 201){
        console.log("success");
      }
       else if(response.status===200) {
         alert("error login");
      }
       alert("Registration Successful");
      navigate("/");
    } catch (error) {
       console.error("Error during signup:", error);
    }
  };
  return (
    <div className="signup-page">
      <form className="form">
        <label htmlFor="username">UserName</label>
        <input
          type="text"
          id="username"
          placeholder="Enter username"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
        required/>
        <label htmlFor="email">Email</label>
        <input
          type="text"
          id="email"
          placeholder="Enter email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        required/>
        <label htmlFor="password">Password</label>
        <input
          type="password"
          id="password"
          placeholder="Enter password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        required/>
        <button type="button" onClick={handleSignup}>Signup</button>
        <p className="login-link">Already have an account? <Link to="/login" className="login-link">Login</Link></p>
      </form>
    </div>
  );
}

export default Signup;
