import React, { useState, useEffect } from "react";
import axios from "axios";
import { useNavigate } from 'react-router-dom';
import './dashboard.css';


function Dashboard() {
  const [userDetails, setUserDetails] = useState(null);
  const [user,setUser] = useState("")
  const navigate = useNavigate()
 
  
    const loggedInUsername = localStorage.getItem("user")
 
  useEffect(() => {
    
    // Fetch user details based on the logged-in username
    axios.get(`http://localhost:8080/api/userdetails/?username=${loggedInUsername}`)
      .then((response) => {
        if (response.status === 200) {
          console.log(userDetails)
          setUserDetails(response.data);
        } else {
          console.error("Error fetching user details:", response.statusText);
        }
      })
      .catch((error) => {
        console.error("Error fetching user details:", error);
      });
  }, [loggedInUsername]);

  if (!userDetails) {
    return <div className="dashboard">Loading...</div>;
  }

  return (
    <div className="dashboard-container">
      <h3 className="dashboard-heading">Welcome to the Dashboard, {userDetails.username}!</h3>
      <p className="dashboard-info">Email: {userDetails.email}</p>
      <p className="dashboard-info">Username: {userDetails.username}</p>
      <button className="btn btn-danger dashboard-logout-button" onClick={() => {
        navigate("/login");
        localStorage.removeItem("user");
      }}>Logout</button>
    </div>
  );
}

export default Dashboard;


